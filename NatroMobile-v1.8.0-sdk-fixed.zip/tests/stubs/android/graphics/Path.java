package android.graphics;

/** Remembers the first and last point, which is all the engine needs to check a stroke. */
public class Path {
    public float firstX, firstY, lastX, lastY;
    private boolean started;
    public void moveTo(float x, float y) {
        if (!started) { firstX = x; firstY = y; started = true; }
        lastX = x; lastY = y;
    }
    public void lineTo(float x, float y) { lastX = x; lastY = y; }
}
