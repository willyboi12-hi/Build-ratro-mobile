package android.graphics;

import android.hardware.HardwareBuffer;
import com.natromobile.Sim;

/** Every pixel reads as Sim.bagColor, which is all the bag reader asks for. */
public class Bitmap {
    public static final class Config {
        public static final Config ARGB_8888 = new Config();
    }
    public static Bitmap wrapHardwareBuffer(HardwareBuffer hb, ColorSpace cs) { return new Bitmap(); }
    public Bitmap copy(Config config, boolean mutable) { return new Bitmap(); }
    public void recycle() {}
    public int getWidth() { return 1080; }
    public int getHeight() { return 2400; }
    public int getPixel(int x, int y) { return Sim.pixelAt(x, y); }
}
