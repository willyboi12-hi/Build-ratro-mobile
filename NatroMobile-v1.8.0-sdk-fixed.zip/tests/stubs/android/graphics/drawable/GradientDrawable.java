package android.graphics.drawable;

public class GradientDrawable extends Drawable {
    public static final int OVAL = 1;
    public GradientDrawable() {}
    public void setColor(int color) {}
    public void setCornerRadius(float radius) {}
    public void setShape(int shape) {}
    public void setStroke(int width, int color) {}
}
