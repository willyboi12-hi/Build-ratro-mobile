package android.util;

/** A 1080x2400 phone at 2.75 density. */
public class DisplayMetrics {
    public int widthPixels = 1080;
    public int heightPixels = 2400;
    public float density = 2.75f;
}
