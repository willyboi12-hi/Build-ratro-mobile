package android.content;

import android.net.Uri;

public class Intent {
    public static final String ACTION_VIEW = "android.intent.action.VIEW";
    public static final int FLAG_ACTIVITY_NEW_TASK = 0x10000000;
    public String action, data;
    public Intent() {}
    public Intent(Context c, Class<?> cls) {}
    public Intent(String action) { this.action = action; }
    public Intent(String action, Uri uri) { this.action = action; this.data = uri == null ? null : uri.toString(); }
    public Intent addFlags(int flags) { return this; }
}
