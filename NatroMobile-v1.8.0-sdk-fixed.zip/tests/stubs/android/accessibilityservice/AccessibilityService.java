package android.accessibilityservice;

import android.app.Service;
import android.content.Context;
import android.hardware.HardwareBuffer;
import android.graphics.ColorSpace;
import android.os.Handler;
import android.view.accessibility.AccessibilityEvent;
import com.natromobile.Sim;
import java.util.concurrent.Executor;

/** Runs gestures on the simulated clock. Sim decides whether they are accepted or cancelled. */
public class AccessibilityService extends Service {
    protected void onServiceConnected() {}
    public void onAccessibilityEvent(AccessibilityEvent event) {}
    public void onInterrupt() {}

    public boolean dispatchGesture(final GestureDescription g, final GestureResultCallback cb, Handler handler) {
        if (!Sim.acceptGestures) return false;
        GestureDescription.StrokeDescription s = g.first();
        Sim.record(s);
        final boolean cancel = Sim.cancelAll;
        Sim.post(null, s.duration, new Runnable() {
            @Override public void run() {
                if (cb == null) return;
                if (cancel) cb.onCancelled(g); else cb.onCompleted(g);
            }
        });
        return true;
    }

    public void takeScreenshot(int displayId, Executor executor, final TakeScreenshotCallback cb) {
        Sim.post(null, 80, new Runnable() {
            @Override public void run() {
                if (Sim.failShots) cb.onFailure(3);
                else cb.onSuccess(new ScreenshotResult());
            }
        });
    }

    public static abstract class GestureResultCallback {
        public void onCompleted(GestureDescription gestureDescription) {}
        public void onCancelled(GestureDescription gestureDescription) {}
    }

    public interface TakeScreenshotCallback {
        void onSuccess(ScreenshotResult result);
        void onFailure(int errorCode);
    }

    public static final class ScreenshotResult {
        public HardwareBuffer getHardwareBuffer() { return new HardwareBuffer(); }
        public ColorSpace getColorSpace() { return null; }
    }
}
