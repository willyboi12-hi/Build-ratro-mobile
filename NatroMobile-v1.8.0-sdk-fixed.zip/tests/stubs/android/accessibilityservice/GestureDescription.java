package android.accessibilityservice;

import android.graphics.Path;
import com.natromobile.Sim;
import java.util.ArrayList;
import java.util.List;

/** Keeps each stroke's start and end points so the simulator can log them. Warns on the same misuse Android rejects. */
public class GestureDescription {
    final List<StrokeDescription> strokes;
    GestureDescription(List<StrokeDescription> strokes) { this.strokes = strokes; }
    public StrokeDescription first() { return strokes.get(0); }

    public static final class Builder {
        private final List<StrokeDescription> strokes = new ArrayList<StrokeDescription>();
        public Builder addStroke(StrokeDescription s) { strokes.add(s); return this; }
        public GestureDescription build() { return new GestureDescription(strokes); }
    }

    public static final class StrokeDescription {
        public final float x0, y0, x1, y1;
        public final long start, duration;
        public final boolean willContinue;

        public StrokeDescription(Path p, long start, long duration) { this(p, start, duration, false); }

        public StrokeDescription(Path p, long start, long duration, boolean willContinue) {
            if (duration <= 0) Sim.warn("stroke duration must be positive");
            x0 = p.firstX; y0 = p.firstY; x1 = p.lastX; y1 = p.lastY;
            this.start = start; this.duration = duration; this.willContinue = willContinue;
        }

        /** Android requires a continued stroke to start where the previous one ended. */
        public StrokeDescription continueStroke(Path p, long start, long duration, boolean willContinue) {
            if (p.firstX != x1 || p.firstY != y1) {
                Sim.warn("continueStroke starts at " + p.firstX + "," + p.firstY + " but the last stroke ended at " + x1 + "," + y1);
            }
            return new StrokeDescription(p, start, duration, willContinue);
        }
    }
}
