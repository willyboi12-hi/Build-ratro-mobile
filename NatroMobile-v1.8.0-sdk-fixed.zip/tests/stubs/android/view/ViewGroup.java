package android.view;

import android.content.Context;

public class ViewGroup extends View {
    public ViewGroup(Context c) { super(c); }
    public void addView(View v) {}
    public void addView(View v, LayoutParams lp) {}
    public void removeAllViews() {}

    public static class LayoutParams {
        public static final int MATCH_PARENT = -1;
        public static final int WRAP_CONTENT = -2;
        public LayoutParams(int width, int height) {}
    }

    public static class MarginLayoutParams extends LayoutParams {
        public int leftMargin, topMargin, rightMargin, bottomMargin;
        public MarginLayoutParams(int width, int height) { super(width, height); }
        public void setMargins(int l, int t, int r, int b) { leftMargin = l; topMargin = t; rightMargin = r; bottomMargin = b; }
    }
}
