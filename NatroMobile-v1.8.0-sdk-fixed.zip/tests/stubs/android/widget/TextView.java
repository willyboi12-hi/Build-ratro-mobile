package android.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.view.View;

public class TextView extends View {
    public TextView(Context c) { super(c); }
    public void setText(CharSequence s) {}
    public CharSequence getText() { return ""; }
    public void setTextColor(int color) {}
    public void setTextSize(float size) {}
    public void setTypeface(Typeface t, int style) {}
    public void setHint(CharSequence hint) {}
    public void setHintTextColor(int color) {}
    public void setSingleLine(boolean single) {}
    public void setInputType(int type) {}
}
