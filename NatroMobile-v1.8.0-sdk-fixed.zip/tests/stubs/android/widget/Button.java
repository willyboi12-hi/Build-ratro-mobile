package android.widget;

import android.content.Context;

public class Button extends TextView {
    public Button(Context c) { super(c); }
    public void setAllCaps(boolean allCaps) {}
}
