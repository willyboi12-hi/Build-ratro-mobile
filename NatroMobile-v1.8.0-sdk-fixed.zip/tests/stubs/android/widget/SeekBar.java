package android.widget;

import android.content.Context;
import android.view.View;

public class SeekBar extends View {
    public SeekBar(Context c) { super(c); }
    public void setMax(int max) {}
    public void setProgress(int progress) {}
    public void setOnSeekBarChangeListener(OnSeekBarChangeListener l) {}

    public interface OnSeekBarChangeListener {
        void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser);
        void onStartTrackingTouch(SeekBar seekBar);
        void onStopTrackingTouch(SeekBar seekBar);
    }
}
