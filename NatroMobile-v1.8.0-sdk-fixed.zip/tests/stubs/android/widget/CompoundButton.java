package android.widget;

import android.content.Context;

public class CompoundButton extends Button {
    public CompoundButton(Context c) { super(c); }
    public void setChecked(boolean checked) {}
    public void setOnCheckedChangeListener(OnCheckedChangeListener l) {}
    public interface OnCheckedChangeListener { void onCheckedChanged(CompoundButton button, boolean checked); }
}
