package android.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

public class Activity extends Context {
    protected void onCreate(Bundle saved) {}
    protected void onResume() {}
    public void setContentView(View v) {}
    public ActionBar getActionBar() { return new ActionBar(); }
    public Window getWindow() { return new Window(); }
    public boolean moveTaskToBack(boolean nonRoot) { return true; }
}
