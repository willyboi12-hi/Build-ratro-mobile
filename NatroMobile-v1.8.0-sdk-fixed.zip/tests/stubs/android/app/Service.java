package android.app;

import android.content.Context;
import android.content.Intent;

public class Service extends Context {
    public boolean onUnbind(Intent intent) { return false; }
    public void onDestroy() {}
}
