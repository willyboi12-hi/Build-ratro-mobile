package android.app;

public class ActionBar {
    public void hide() {}
}
