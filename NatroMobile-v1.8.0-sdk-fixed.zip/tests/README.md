# Engine simulation tests

These tests run the app's engine on a fake clock, with no phone and no Android SDK. They check the gestures the engine sends: where each one starts and ends, how long it lasts, and the order of taps and walks.

Run them with `bash tests/run.sh`. It needs only a JDK. CI runs them before every APK build.

## How it works
- `tests/stubs/` holds small stand-ins for the Android classes the engine uses (gestures, handlers, views, preferences). The stubs are written from memory of the Android API and are not the real `android.jar`.
- `tests/unit/com/natromobile/Sim.java` is a fake clock. Anything the engine schedules runs in time order when a test calls `runUntil(t)`. It also logs every gesture and can refuse, cancel, or fail gestures, and it sets the color of the bag pixel.
- `tests/unit/com/natromobile/RunTests.java` holds the checks.

## What is covered
- Bag color reading and averaging.
- Field routes: 17 fields, each with a route; Clover's first step matches Natro.
- Pattern geometry for every pattern and size.
- Phase 5, first slice: the five translated collect routes match Natro's walk lines for all six hive slots, and walking back undoes the walk there; a due trip runs after a convert and walks back to the field; no trip runs without setup; the trip test taps its spot once.
- Phase 5: all 28 translated collect routes match Natro's walk lines for every hive slot and both bee variants (336 rows); walking back undoes both the walk and the camera turns; the bee count picks the right variant; a route that turns swipes the camera at the camera spot, and is skipped with a message without one; a due trip runs after a convert and walks back; no trip without setup; the trip test taps once.
- Phase 6 (template matching): the matcher finds a picture on a grid, refuses plain pictures and misfits, and saves and loads pictures; the Make Honey picture is saved from the screen, found when it moves a little (within 4 px) and when it is far away, and the fallback uses the last place it was found; the check button reports found or not found with the score.
- Phase 4: Auryn, CornerXSnake, SuperCat and e_lol, checked against totals computed separately from Natro's files (48 cases); walk-speed calibration clamps and scaling; the walk check moves right and reports when it finishes.
- Saved taps and settings parsing.
- Start refuses without a joystick spot.
- The first move starts at the joystick and goes the way the pattern says.
- Stop lifts the thumb and sends nothing more.
- Timed item: used at start, and again after its interval; item test.
- Stop-when-full, refused gestures, and cancelled gestures stop the macro with a message.
- Convert at a full bag: reset taps, then convert tap, then walk back to the field along the route, then farming resumes.
- Walk first: reset, ramp, then route, before farming.
- Joystick test.
- Roblox leaving the screen: 8 seconds off the screen rejoins; Roblox back clears the timer; system UI and the app's own windows are ignored; the watch can be turned off; no link stops with a message; window events during a rejoin are ignored.
- Game links become roblox:// links; share links and roblox:// links are kept as they are.
- Saving the disconnect spot records the average color; one stray dark pixel does not break the match; a different screen does not match.
- Reconnect: no link means a message and nothing opened; a normal screen does not rejoin; a disconnect opens the link, waits, resets, walks back, and farms once; the test rejoin button works.

## What is NOT covered
- How Android actually handles gestures, overlays, screenshots and permissions. The stubs accept whatever the engine asks for, so only a real phone can confirm those.
- Real pixel colors in Roblox. The bag and disconnect tests set colors directly.
- The tap on the save overlay itself. The tests call the saving step with a simulated screenshot, but a real finger on the overlay is phone-only.
- Whether Roblox moves the character the distance the routes assume. That is set by walk speed and only a phone can tell you.
- What the screens look like. The UI is compiled against the stubs but not run.

If a stub's signature differs from the real Android API, the tests can pass while the real build fails. The real APK build in CI is the check for that.
