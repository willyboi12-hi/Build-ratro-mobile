# Build instructions

## Requirements
- JDK 17
- Gradle 8.9
- Android SDK Platform 35
- Android Build Tools 35.0.0

## Run JVM and sandbox tests
```bash
bash tests/run.sh
```
No Android SDK is needed for this test command.

## Build Android app
```bash
gradle :app:lintDebug --no-daemon
gradle :app:assembleDebug --no-daemon
gradle :app:assembleRelease --no-daemon
```

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

Release APK: `app/build/outputs/apk/release/app-release-unsigned.apk` (unsigned unless a separate signing setup is configured).

The repository currently has no Gradle wrapper. CI installs Gradle 8.9. For reproducible local builds, install the same version or add a wrapper after verifying its distribution checksum.
