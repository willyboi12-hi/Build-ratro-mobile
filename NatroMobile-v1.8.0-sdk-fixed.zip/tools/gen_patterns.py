#!/usr/bin/env python3
"""
Translates Natro Macro's extra gather patterns (patterns/Auryn, CornerXSnake, SuperCat, e_lol .ahk)
into Java, and writes independent expected totals for the tests.

Writes:
  <java dir>/ExtraPatterns.java        the walking code, translated line by line
  <unit test dir>/PatternExpectations.java  totals computed by evaluating Natro's file directly in Python

Usage: python3 gen_patterns.py <Natro patterns folder> <java package folder> <unit test package folder>
Natro is GPL v3; the translated code is derived from it.
"""
import math
import re
import sys

PATTERNS = ["Auryn", "CornerXSnake", "SuperCat", "e_lol"]

# Key variables Natro uses, with the Java constant for each and the bit used in Python.
KEY_JAVA = {"TCLRKey": "PatternBuilder.TCLR", "AFCLRKey": "PatternBuilder.AFCLR",
            "TCFBKey": "PatternBuilder.TCFB", "AFCFBKey": "PatternBuilder.AFCFB"}
KEY_BIT = {"TCLRKey": 1, "AFCLRKey": 2, "TCFBKey": 4, "AFCFBKey": 8}
KEY_RE = re.compile(r'(TCLRKey|AFCLRKey|TCFBKey|AFCFBKey)\s*"?\s*(down|up)')


def clean_lines(text):
    lines = []
    for raw in text.replace("\ufeff", "").replace("\r", "").split("\n"):
        line = raw.split(";")[0].strip()   # Natro comments start with ;
        if line:
            lines.append(line)
    return lines


def parse(lines):
    """Returns (body, constants). Loops become ("loop", count_name, [children])."""
    body, consts = [], {}
    stack = [body]
    for line in lines:
        m = re.match(r"^(\w+)\s*:=\s*(.+)$", line)
        if m:
            consts[m.group(1)] = m.group(2).strip()
            continue
        m = re.match(r"^loop\s+(\w+)\s*\{$", line)
        if m:
            node = ("loop", m.group(1), [])
            stack[-1].append(node)
            stack.append(node[2])
            continue
        if line == "}":
            stack.pop()
            continue
        stack[-1].append(("stmt", line))
    assert len(stack) == 1, "unbalanced braces"
    return body, consts


def first_arg(line, call):
    """Text of the first argument of call( ... ), splitting at top-level commas."""
    start = line.index(call) + len(call)
    depth, cur = 0, ""
    for ch in line[start:]:
        if ch == "(":
            depth += 1
        elif ch == ")":
            if depth == 0:
                return cur.strip()
            depth -= 1
        elif ch == "," and depth == 0:
            return cur.strip()
        cur += ch
    raise ValueError("no closing paren: " + line)


# ---------------------------------------------------------------- Python evaluation (for the expectations)

def eval_py(expr, env):
    expr = expr.replace("Sqrt(", "math.sqrt(")
    return eval(expr, {"math": math}, env)


def run_python(body, consts, size, reps, facing):
    env0 = {"size": size, "reps": reps, "facingcorner": 1 if facing else 0}
    for k, v in consts.items():
        env0[k] = float(eval_py(v, {}))
    events = []
    state = {"held": 0}

    def stmt(line, env):
        if line.startswith("send"):
            for key, st in KEY_RE.findall(line):
                bit = KEY_BIT[key]
                state["held"] = (state["held"] | bit) if st == "down" else (state["held"] & ~bit)
        elif line.startswith("Walk("):
            tiles = float(eval_py(first_arg(line, "Walk("), env))
            if state["held"] == 0:
                raise ValueError("Walk with no key held: " + line)
            events.append(("walk", tiles))
        elif line.lower().startswith("hypersleep("):
            events.append(("pause", float(eval_py(first_arg(line, "HyperSleep("), env)) / 1000.0))
        else:
            raise ValueError("unhandled line: " + line)

    def run(nodes, env):
        for node in nodes:
            if node[0] == "loop":
                count = int(env[node[1]])
                for i in range(1, count + 1):
                    env2 = dict(env)
                    env2["A_Index"] = float(i)
                    run(node[2], env2)
            else:
                stmt(node[1], env)

    run(body, env0)
    walks = [e for e in events if e[0] == "walk"]
    pauses = [e for e in events if e[0] == "pause"]
    return {"walks": len(walks), "tiles": sum(e[1] for e in walks),
            "pauses": len(pauses), "secs": sum(e[1] for e in pauses), "held_end": state["held"]}


# ---------------------------------------------------------------- Java translation

TOKEN = re.compile(r"\s*(\*\*|[A-Za-z_]\w*|\d+(?:\.\d+)?|[()+\-*/,])")
IDENT = {"size": "size", "reps": "R", "A_Index": "A", "facingcorner": "FC"}


def tokens(s):
    out, pos = [], 0
    while pos < len(s.rstrip()):
        m = TOKEN.match(s, pos)
        if not m:
            raise ValueError("cannot read %r at %d" % (s, pos))
        out.append(m.group(1))
        pos = m.end()
    return out


class JavaExpr:
    """Recursive-descent translation of an AHK arithmetic expression into a Java double expression."""

    def __init__(self, toks):
        self.t, self.i = toks, 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else None

    def eat(self, want=None):
        tok = self.peek()
        if want is not None and tok != want:
            raise ValueError("expected %r, found %r" % (want, tok))
        self.i += 1
        return tok

    def parse(self):
        v = self.expr()
        if self.peek() is not None:
            raise ValueError("unexpected %r" % self.peek())
        return v

    def expr(self):
        v = self.term()
        while self.peek() in ("+", "-"):
            op = self.eat()
            v = "(%s %s %s)" % (v, op, self.term())
        return v

    def term(self):
        v = self.unary()
        while self.peek() in ("*", "/"):
            op = self.eat()
            v = "(%s %s %s)" % (v, op, self.unary())
        return v

    def unary(self):
        if self.peek() == "-":
            self.eat()
            return "(-%s)" % self.unary()
        return self.power()

    def power(self):
        base = self.primary()
        if self.peek() == "**":
            self.eat()
            return "Math.pow(%s, %s)" % (base, self.unary())
        return base

    def primary(self):
        tok = self.eat()
        if tok == "(":
            v = self.expr()
            self.eat(")")
            return "(%s)" % v
        if tok[0].isdigit():
            return tok if "." in tok else tok + ".0"
        if tok == "Sqrt":
            self.eat("(")
            v = self.expr()
            self.eat(")")
            return "Math.sqrt(%s)" % v
        if tok[0].isalpha() or tok[0] == "_":
            return IDENT.get(tok, tok)
        raise ValueError("unexpected token %r" % tok)


def java_block(body, ind):
    lines = []

    def stmt(line, ind):
        if line.startswith("send"):
            for key, st in KEY_RE.findall(line):
                lines.append("%sb.%s(%s);" % (ind, "down" if st == "down" else "up", KEY_JAVA[key]))
        elif line.startswith("Walk("):
            lines.append("%sb.walk(%s);" % (ind, JavaExpr(tokens(first_arg(line, "Walk("))).parse()))
        elif line.lower().startswith("hypersleep("):
            lines.append("%sb.pause((%s) / 1000.0);" % (ind, JavaExpr(tokens(first_arg(line, "HyperSleep("))).parse()))
        else:
            raise ValueError("unhandled line: " + line)

    def run(nodes, ind):
        for node in nodes:
            if node[0] == "loop":
                assert node[1] == "reps", "only 'loop reps' is expected"
                lines.append(ind + "for (int i = 1; i <= reps; i++) {")
                lines.append(ind + "    final double A = i;")
                run(node[2], ind + "    ")
                lines.append(ind + "}")
            else:
                stmt(node[1], ind)

    run(body, ind)
    return lines


def java_method(name, body, consts):
    lines = ["    static void %s(PatternBuilder b, double size, int reps, boolean facingCorner) {" % name.lower()
             .replace("-", "_"),
             "        final double R = reps;",
             "        final double FC = facingCorner ? 1.0 : 0.0;"]
    for k, v in consts.items():
        lines.append("        final double %s = %s;" % (k, JavaExpr(tokens(v)).parse()))
    lines += java_block(body, "        ")
    lines.append("    }")
    return lines


def main():
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    pdir, java_dir, test_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    parsed = {}
    for name in PATTERNS:
        with open("%s/%s.ahk" % (pdir, name), encoding="utf-8", errors="replace") as fh:
            parsed[name] = parse(clean_lines(fh.read()))

    # Java: ExtraPatterns.java
    out = [
        "package com.natromobile;",
        "",
        "// GENERATED by tools/gen_patterns.py from Natro Macro v1.1.2 patterns/*.ahk (GNU GPL v3).",
        "// Do not edit by hand. Keys: TCLR/AFCLR (toward / away from center, left-right), TCFB/AFCFB (forward-back).",
        "public final class ExtraPatterns {",
        "    public static final String[] NAMES = {%s};" % ", ".join('"%s"' % n for n in PATTERNS),
        "",
        "    private ExtraPatterns() {}",
        "",
        "    public static boolean has(String name) {",
        "        for (String n : NAMES) if (n.equals(name)) return true;",
        "        return false;",
        "    }",
        "",
        "    /** Adds the steps of the named pattern to b. size is the size factor, reps the repeat count. */",
        "    public static void build(String name, PatternBuilder b, double size, int reps, boolean facingCorner) {",
    ]
    for name in PATTERNS:
        out.append('        if ("%s".equals(name)) %s(b, size, reps, facingCorner);' % (name, name.lower().replace("-", "_")))
    out += ["    }", ""]
    for name in PATTERNS:
        body, consts = parsed[name]
        out += java_method(name, body, consts)
        out.append("")
    out.append("}")
    with open("%s/ExtraPatterns.java" % java_dir, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")

    # Expectations, from direct Python evaluation of the same files.
    rows = []
    for name in PATTERNS:
        body, consts = parsed[name]
        for size in (0.5, 1.0, 2.0):
            for reps in (1, 3):
                for facing in (False, True):
                    r = run_python(body, consts, size, reps, facing)
                    rows.append('        {"%s", %s, %d, %s, %d, %.6f, %d, %.6f, %d},' % (
                        name, repr(size), reps, "true" if facing else "false",
                        r["walks"], r["tiles"], r["pauses"], r["secs"], r["held_end"]))
    test = [
        "package com.natromobile;",
        "",
        "// GENERATED by tools/gen_patterns.py. Totals come from evaluating Natro's .ahk files directly in Python,",
        "// separately from the Java translation, so the test checks the translation.",
        "// Fields: name, size, reps, facing corner, walk count, total tiles, pause count, total pause seconds, keys held at end.",
        "final class PatternExpectations {",
        "    static final Object[][] ROWS = {",
    ] + rows + ["    };", "}", ""]
    with open("%s/PatternExpectations.java" % test_dir, "w", encoding="utf-8") as fh:
        fh.write("\n".join(test))
    print("wrote %d expectation rows; translated %d patterns" % (len(rows), len(PATTERNS)))


if __name__ == "__main__":
    main()
