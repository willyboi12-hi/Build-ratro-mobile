# Production readiness

Status is evidence-based. A source-level test pass is not proof of Android production readiness.

| Gate | Status | Evidence / next action |
|---|---|---|
| Supplied ZIP integrity | PASS | `ZipFile.testzip()` returned no corrupt entry |
| Baseline JVM suite | PASS | 739 passed, 0 failed |
| Expanded JVM + sandbox suite | PASS | 750 passed, 0 failed |
| Gradle project configuration | CONFIGURED | Settings and Java compatibility added; run Gradle |
| Android lint | NOT RUN | Run `gradle :app:lintDebug` in Android SDK environment |
| Debug APK | NOT RUN | Run `gradle :app:assembleDebug` |
| Unsigned release APK | NOT RUN | Run `gradle :app:assembleRelease` |
| Real device validation | NOT RUN | Follow `DEVICE_TEST_MATRIX.md` |
| Release signing | NOT CONFIGURED | Use owner-controlled key outside repository |

## Release blockers
1. Execute the CI workflow and resolve all Gradle, manifest, lint, and compilation errors.
2. Install on supported physical Android devices and complete the device matrix.
3. Validate screen capture and gesture behavior under actual device lifecycle conditions.
4. Review permissions, privacy behavior, and source licensing.
5. Sign the release APK with a securely stored owner-managed key.

Do not label the project production-ready until every required gate has evidence.
