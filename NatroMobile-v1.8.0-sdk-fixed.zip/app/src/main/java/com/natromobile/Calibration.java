package com.natromobile;

/** Walk-speed check: scales the speed by how far the character really walked compared with what was expected. */
public final class Calibration {
    /** The check walks this many tiles. */
    public static final double EXPECTED_TILES = 10.0;
    /** Same range as the Walk speed slider in Advanced. */
    public static final double MIN_SPEED = 10.0, MAX_SPEED = 60.0;

    /**
     * Speed that would have covered the observed distance in the time the expected distance took.
     * Keeps the old speed when the input makes no sense, and stays inside the slider range.
     */
    public static float speedFor(float oldSpeed, double expectedTiles, double observedTiles) {
        if (oldSpeed <= 0 || expectedTiles <= 0 || observedTiles <= 0) return oldSpeed;
        double s = oldSpeed * observedTiles / expectedTiles;
        return (float) Math.max(MIN_SPEED, Math.min(MAX_SPEED, s));
    }
}
