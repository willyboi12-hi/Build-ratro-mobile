package com.natromobile;

import java.util.ArrayList;
import java.util.List;

/**
 * Collects a pattern's steps the way Natro's send/Walk lines do: keys are held down and released,
 * and each walk moves in whatever direction the held keys make.
 * Keys are named the way Natro names them: TC = toward the center of the field, AFC = away from it.
 */
public final class PatternBuilder {
    public static final int TCLR = 1, AFCLR = 2, TCFB = 4, AFCFB = 8;

    private final boolean invFB, invLR;
    private int held;
    private final List<Patterns.Seg> out = new ArrayList<Patterns.Seg>();

    public PatternBuilder(boolean invFB, boolean invLR) {
        this.invFB = invFB;
        this.invLR = invLR;
    }

    public void down(int key) { held |= key; }
    public void up(int key) { held &= ~key; }

    /** Walks the given number of tiles in the direction the held keys make. */
    public void walk(double tiles) {
        int lr = ((held & TCLR) != 0 ? 1 : 0) - ((held & AFCLR) != 0 ? 1 : 0);
        int fb = ((held & TCFB) != 0 ? 1 : 0) - ((held & AFCFB) != 0 ? 1 : 0);
        if (lr == 0 && fb == 0) throw new IllegalStateException("walk with no key held");
        // Toward-center left/right is Left unless flipped; toward-center forward is Forward unless flipped.
        int tcLR = invLR ? 1 : -1;
        int tcFB = invFB ? 1 : -1;
        out.add(new Patterns.Seg(lr * tcLR, fb * tcFB, tiles, -1));
    }

    /** A pause with no movement (Natro's HyperSleep). */
    public void pause(double seconds) { out.add(new Patterns.Seg(0, 0, 0, seconds)); }

    public List<Patterns.Seg> steps() { return out; }

    /** Keys still held. A finished pattern should leave none held. */
    public int heldKeys() { return held; }
}
