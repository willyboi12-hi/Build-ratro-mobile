package com.natromobile.overlay;

import com.natromobile.MacroAccessibilityService;

/**
 * Thin safe bridge between overlay UI and the real macro engine.
 * Only exposes supported public methods. No internal access.
 */
public final class OverlayMacroController {

    public boolean isConnected() {
        return MacroAccessibilityService.instance != null;
    }

    public boolean isRunning() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        return s != null && s.isRunning();
    }

    public String getStatus() {
        return MacroAccessibilityService.status != null ? MacroAccessibilityService.status : "Not connected";
    }

    public String getBagLine() {
        return MacroAccessibilityService.bagLine != null ? MacroAccessibilityService.bagLine : "Bag: --";
    }

    public void start() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.startMacro();
    }

    public void startDelayed(long ms) {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.startDelayed(ms);
    }

    public void stop() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.stopMacro();
    }

    public void emergencyStop() {
        stop();
    }

    /** Pause and resume are not supported by the current macro engine. */
    public boolean supportsPause() {
        return false;
    }

    public void pause() {
        // unsupported
    }

    public void resume() {
        // unsupported
    }
}
