package com.natromobile.overlay;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.natromobile.MainActivity;
import com.natromobile.Ui;

/**
 * Premium floating dashboard panel.
 * Blue / black theme matching the reference images.
 */
public class OverlayDashboardView extends FrameLayout {

    public interface Listener {
        void onMinimize();
        void onClose();
        void onDragEnd(int x, int y);
    }

    private final Ui ui;
    private final OverlaySettings settings;
    private final OverlayMacroController macro;
    private Listener listener;
    private WindowManager.LayoutParams lp;

    private LinearLayout rootCard;
    private TextView statusTitle;
    private TextView statusSub;
    private TextView runtimeText;
    private TextView bagText;
    private TextView footerStatus;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusTicker = this::tickStatus;
    private boolean tickerRunning;

    private float downRawX, downRawY;
    private int startX, startY;
    private boolean moved;
    private int currentTab = 0;
    private LinearLayout contentHost;
    private Button[] tabButtons;

    public OverlayDashboardView(Context c, Ui ui, OverlaySettings settings, OverlayMacroController macro) {
        super(c);
        this.ui = ui;
        this.settings = settings;
        this.macro = macro;
        currentTab = settings.getLastTab();
        build();
    }

    public void setListener(Listener l) { this.listener = l; }
    public void setLayoutParams(WindowManager.LayoutParams params) { this.lp = params; }

    private void build() {
        int width = ui.dp(340);
        setLayoutParams(new LayoutParams(width, LayoutParams.WRAP_CONTENT));

        rootCard = new LinearLayout(getContext());
        rootCard.setOrientation(LinearLayout.VERTICAL);
        rootCard.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF50E1218);
        bg.setCornerRadius(ui.dp(22));
        bg.setStroke(ui.dp(2), 0xAA3B82F6);
        rootCard.setBackground(bg);
        rootCard.setElevation(ui.dp(20));
        rootCard.setAlpha(settings.getTransparency());

        // Header
        rootCard.addView(buildHeader());
        // Tabs
        rootCard.addView(buildTabs());
        // Content
        contentHost = new LinearLayout(getContext());
        contentHost.setOrientation(LinearLayout.VERTICAL);
        rootCard.addView(contentHost, ui.full(0));
        // Footer
        rootCard.addView(buildFooter());

        addView(rootCard, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        // Drag from header area
        rootCard.setOnTouchListener(this::onDragTouch);

        showTab(currentTab);
        startTicker();
    }

    private LinearLayout buildHeader() {
        LinearLayout header = new LinearLayout(getContext());
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, ui.dp(10));

        // Logo N
        TextView logo = new TextView(getContext());
        logo.setText("N");
        logo.setTextColor(Ui.BLUE_LIGHT);
        logo.setTextSize(20);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable logoBg = new GradientDrawable();
        logoBg.setShape(GradientDrawable.RECTANGLE);
        logoBg.setCornerRadius(ui.dp(10));
        logoBg.setColor(Ui.BLUE_NAVY);
        logoBg.setStroke(ui.dp(1), Ui.BLUE_GLOW);
        logo.setBackground(logoBg);
        logo.setPadding(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(4));
        header.addView(logo);

        LinearLayout titles = new LinearLayout(getContext());
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(ui.dp(10), 0, 0, 0);
        TextView title = ui.text("NATRO MOBILE", Ui.TEXT, 15, true);
        TextView sub = ui.text("Bee Swarm Automation", Ui.MUTED, 11, false);
        titles.addView(title);
        titles.addView(sub);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        header.addView(titles, tlp);

        // Status pill
        TextView runningPill = ui.text("● Macro", Ui.BLUE_LIGHT, 11, true);
        runningPill.setPadding(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(4));
        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setCornerRadius(ui.dp(20));
        pillBg.setColor(0x331E3A8A);
        runningPill.setBackground(pillBg);
        header.addView(runningPill);
        statusTitle = runningPill; // reuse

        // Minimize
        Button min = makeIconBtn("—");
        min.setOnClickListener(v -> { if (listener != null) listener.onMinimize(); });
        header.addView(min);

        // Close
        Button close = makeIconBtn("✕");
        close.setOnClickListener(v -> { if (listener != null) listener.onClose(); });
        header.addView(close);

        return header;
    }

    private Button makeIconBtn(String t) {
        Button b = new Button(getContext());
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Ui.MUTED);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(ui.dp(10));
        g.setColor(Ui.CARD_HI);
        b.setBackground(g);
        return b;
    }

    private HorizontalScrollView buildTabs() {
        HorizontalScrollView hsv = new HorizontalScrollView(getContext());
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 0, 0, ui.dp(10));

        String[] labels = {"Home", "Farming", "Quests", "Inventory", "Settings"};
        tabButtons = new Button[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            Button b = new Button(getContext());
            b.setText(labels[i]);
            b.setAllCaps(false);
            b.setTextSize(12);
            b.setTextColor(i == currentTab ? Ui.TEXT : Ui.MUTED);
            b.setMinHeight(ui.dp(34));
            b.setMinimumHeight(ui.dp(34));
            b.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6));
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(ui.dp(10));
            g.setColor(i == currentTab ? Ui.BLUE_GLOW : Ui.CARD_HI);
            b.setBackground(g);
            b.setOnClickListener(v -> showTab(idx));
            tabButtons[i] = b;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, ui.dp(6), 0);
            row.addView(b, lp);
        }
        hsv.addView(row);
        return hsv;
    }

    private void showTab(int idx) {
        currentTab = idx;
        settings.setLastTab(idx);
        for (int i = 0; i < tabButtons.length; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(ui.dp(10));
            g.setColor(i == idx ? Ui.BLUE_GLOW : Ui.CARD_HI);
            tabButtons[i].setBackground(g);
            tabButtons[i].setTextColor(i == idx ? Ui.TEXT : Ui.MUTED);
        }
        contentHost.removeAllViews();
        switch (idx) {
            case 0: contentHost.addView(buildHomeTab()); break;
            case 1: contentHost.addView(buildFarmingTab()); break;
            case 2: contentHost.addView(buildQuestsTab()); break;
            case 3: contentHost.addView(buildInventoryTab()); break;
            case 4: contentHost.addView(buildSettingsTab()); break;
        }
    }

    private LinearLayout buildHomeTab() {
        LinearLayout col = new LinearLayout(getContext());
        col.setOrientation(LinearLayout.VERTICAL);

        // Status card - matches reference layout
        LinearLayout statusCard = makeCard();
        LinearLayout row1 = new LinearLayout(getContext());
        row1.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout left = new LinearLayout(getContext());
        left.setOrientation(LinearLayout.VERTICAL);
        statusSub = ui.text(macro.getStatus(), Ui.MUTED, 11, false);
        TextView stLabel = ui.text("Macro Status", Ui.MUTED, 11, false);
        TextView stValue = ui.text(macro.isRunning() ? "Running" : "Stopped",
            macro.isRunning() ? Ui.BLUE_LIGHT : Ui.MUTED, 18, true);
        statusTitle = stValue;
        left.addView(stLabel);
        left.addView(stValue);
        left.addView(statusSub);
        LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.2f);
        row1.addView(left, leftLp);

        View divider1 = new View(getContext());
        divider1.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ui.dp(1), ui.dp(40));
        dlp.setMargins(ui.dp(6), 0, ui.dp(6), 0);
        row1.addView(divider1, dlp);

        LinearLayout mid = new LinearLayout(getContext());
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER_HORIZONTAL);
        mid.addView(ui.text("Runtime", Ui.MUTED, 11, false));
        runtimeText = ui.text("00:00:00", Ui.TEXT, 16, true);
        mid.addView(runtimeText);
        LinearLayout.LayoutParams midLp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        row1.addView(mid, midLp);

        View divider2 = new View(getContext());
        divider2.setBackgroundColor(0x33FFFFFF);
        row1.addView(divider2, dlp);

        LinearLayout right = new LinearLayout(getContext());
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER_HORIZONTAL);
        right.addView(ui.text("Bag", Ui.MUTED, 11, false));
        bagText = ui.text("--", Ui.TEXT, 16, true);
        right.addView(bagText);
        LinearLayout.LayoutParams rightLp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        row1.addView(right, rightLp);

        statusCard.addView(row1);
        col.addView(statusCard, ui.full(8));

        // Control buttons row - Start Stop Pause Resume Emergency
        LinearLayout controls = new LinearLayout(getContext());
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(makeActionBtn("Start", Ui.BLUE_GLOW, v -> macro.startDelayed(3000)), weight(1));
        controls.addView(makeActionBtn("Stop", 0xFF3A1A1A, v -> macro.stop()), weight(1));
        controls.addView(makeActionBtn("Pause", 0xFF2A2A1A, v -> {}), weight(1)); // unsupported
        controls.addView(makeActionBtn("Resume", Ui.BLUE_DARK, v -> {}), weight(1)); // unsupported
        controls.addView(makeActionBtn("Emerg", Ui.RED, v -> macro.emergencyStop()), weight(1));
        col.addView(controls, ui.full(8));

        // Two column: Farming Settings + Quick Actions
        LinearLayout twoCol = new LinearLayout(getContext());
        twoCol.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout farmCard = makeCard();
        farmCard.addView(ui.text("Farming Settings", Ui.TEXT, 13, true));
        farmCard.addView(ui.body("Use main app to pick field and enable auto farm. Overlay Start runs the configured plan."));
        LinearLayout.LayoutParams farmLp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        farmLp.setMargins(0, 0, ui.dp(4), 0);
        twoCol.addView(farmCard, farmLp);

        LinearLayout qa = makeCard();
        qa.addView(ui.text("Quick Actions", Ui.TEXT, 13, true));
        LinearLayout qaRow = new LinearLayout(getContext());
        qaRow.setOrientation(LinearLayout.VERTICAL);
        qaRow.setPadding(0, ui.dp(6), 0, 0);
        Button openApp = makeSmallBtn("Open App", v -> {
            Intent i = new Intent(getContext(), MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        });
        Button hide = makeSmallBtn("Hide Panel", v -> {
            if (listener != null) listener.onMinimize();
        });
        qaRow.addView(openApp);
        qaRow.addView(hide);
        qa.addView(qaRow);
        LinearLayout.LayoutParams qaLp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        qaLp.setMargins(ui.dp(4), 0, 0, 0);
        twoCol.addView(qa, qaLp);

        col.addView(twoCol, ui.full(8));

        // Recent activity style card
        LinearLayout recent = makeCard();
        recent.addView(ui.text("Recent Activity", Ui.TEXT, 13, true));
        recent.addView(ui.body("• Status updates appear here when the macro runs"));
        recent.addView(ui.body("• Bag changes and convert events show in the main app log"));
        col.addView(recent, ui.full(0));

        return col;
    }

    private LinearLayout buildFarmingTab() {
        LinearLayout col = new LinearLayout(getContext());
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout card = makeCard();
        card.addView(ui.text("Farming Controls", Ui.TEXT, 14, true));
        card.addView(ui.body("Field selection and auto-farm toggles are controlled from the main app. Use Start / Stop on Home to run the macro."));
        card.addView(ui.body("Current engine does not expose per-field live controls to the overlay yet."));
        col.addView(card, ui.full(0));
        return col;
    }

    private LinearLayout buildQuestsTab() {
        LinearLayout col = new LinearLayout(getContext());
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout card = makeCard();
        card.addView(ui.text("Quests", Ui.TEXT, 14, true));
        card.addView(ui.body("Quest automation is handled by the macro when enabled in the main app. Live quest progress is not currently readable by the overlay."));
        col.addView(card, ui.full(0));
        return col;
    }

    private LinearLayout buildInventoryTab() {
        LinearLayout col = new LinearLayout(getContext());
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout card = makeCard();
        card.addView(ui.text("Inventory", Ui.TEXT, 14, true));
        card.addView(ui.body("Bag reading is live when the macro is connected."));
        TextView bag = ui.text(macro.getBagLine(), Ui.BLUE_LIGHT, 15, true);
        bagText = bag;
        card.addView(bag);
        col.addView(card, ui.full(0));
        return col;
    }

    private LinearLayout buildSettingsTab() {
        LinearLayout col = new LinearLayout(getContext());
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout card = makeCard();
        card.addView(ui.text("Overlay Settings", Ui.TEXT, 14, true));

        card.addView(ui.label("Transparency"));
        SeekBar seek = new SeekBar(getContext());
        seek.setMax(100);
        seek.setProgress((int) (settings.getTransparency() * 100));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean fromUser) {
                if (fromUser) {
                    float t = prog / 100f;
                    settings.setTransparency(t);
                    rootCard.setAlpha(Math.max(0.45f, t));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        card.addView(seek);

        Button reset = ui.secondary("Reset Positions");
        reset.setOnClickListener(v -> {
            settings.resetPositions();
            if (listener != null) listener.onMinimize();
        });
        card.addView(reset, ui.full(0));

        col.addView(card, ui.full(0));
        return col;
    }

    private LinearLayout buildFooter() {
        LinearLayout foot = new LinearLayout(getContext());
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(0, ui.dp(8), 0, 0);
        footerStatus = ui.text("Ready", Ui.MUTED, 11, false);
        foot.addView(footerStatus, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        TextView dragHint = ui.text("Drag to move", Ui.MUTED, 11, false);
        foot.addView(dragHint);
        return foot;
    }

    private LinearLayout makeCard() {
        LinearLayout c = new LinearLayout(getContext());
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Ui.CARD);
        g.setCornerRadius(ui.dp(14));
        g.setStroke(ui.dp(1), 0x22FFFFFF);
        c.setBackground(g);
        return c;
    }

    private Button makeActionBtn(String label, int color, View.OnClickListener click) {
        Button b = new Button(getContext());
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(Ui.TEXT);
        b.setTypeface(null, Typeface.BOLD);
        b.setMinHeight(ui.dp(48));
        b.setMinimumHeight(ui.dp(48));
        b.setPadding(ui.dp(4), ui.dp(8), ui.dp(4), ui.dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(ui.dp(12));
        g.setStroke(ui.dp(1), 0x44FFFFFF);
        b.setBackground(g);
        b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(ui.dp(2), 0, ui.dp(2), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private Button makeSmallBtn(String label, View.OnClickListener click) {
        Button b = new Button(getContext());
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(Ui.TEXT);
        b.setMinHeight(ui.dp(38));
        b.setMinimumHeight(ui.dp(38));
        b.setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Ui.CARD_HI);
        g.setCornerRadius(ui.dp(10));
        g.setStroke(ui.dp(1), 0x333B82F6);
        b.setBackground(g);
        b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, ui.dp(3), 0, ui.dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout.LayoutParams weight(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, w);
        lp.setMargins(ui.dp(3), 0, ui.dp(3), 0);
        return lp;
    }

    private boolean onDragTouch(View v, MotionEvent e) {
        if (lp == null) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = e.getRawX();
                downRawY = e.getRawY();
                startX = lp.x;
                startY = lp.y;
                moved = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = e.getRawX() - downRawX;
                float dy = e.getRawY() - downRawY;
                if (Math.abs(dx) > ui.dp(6) || Math.abs(dy) > ui.dp(6)) moved = true;
                if (moved) {
                    lp.x = startX + (int) dx;
                    lp.y = startY + (int) dy;
                    try {
                        WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
                        if (wm != null) wm.updateViewLayout(this, lp);
                    } catch (Exception ignored) {}
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (moved) {
                    settings.setPanelPos(lp.x, lp.y);
                    if (listener != null) listener.onDragEnd(lp.x, lp.y);
                }
                return true;
            default:
                return false;
        }
    }

    private long startMs = 0;

    private void tickStatus() {
        boolean running = macro.isRunning();
        if (statusTitle != null) {
            statusTitle.setText(running ? "Running" : "Stopped");
            statusTitle.setTextColor(running ? Ui.BLUE_LIGHT : Ui.MUTED);
        }
        if (statusSub != null) {
            statusSub.setText(macro.getStatus());
        }
        if (bagText != null) {
            bagText.setText(macro.getBagLine());
        }
        if (runtimeText != null) {
            if (running) {
                if (startMs == 0) startMs = System.currentTimeMillis();
                long sec = (System.currentTimeMillis() - startMs) / 1000;
                long h = sec / 3600;
                long m = (sec % 3600) / 60;
                long s = sec % 60;
                runtimeText.setText(String.format("%02d:%02d:%02d", h, m, s));
            } else {
                startMs = 0;
                runtimeText.setText("00:00:00");
            }
        }
        if (footerStatus != null) {
            footerStatus.setText(running ? "Macro active" : "Ready");
        }
        if (tickerRunning) handler.postDelayed(statusTicker, 1000);
    }

    public void startTicker() {
        if (tickerRunning) return;
        tickerRunning = true;
        handler.post(statusTicker);
    }

    public void stopTicker() {
        tickerRunning = false;
        handler.removeCallbacks(statusTicker);
    }

    public void refresh() {
        tickStatus();
    }
}
