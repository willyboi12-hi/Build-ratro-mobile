# Natro Mobile (v1.8.0 - template matching for Make Honey)

An Android app for Roblox that repeats Natro Macro's gather patterns, reads your pollen bag from the screen, and can convert at the hive. It is a personal project for a few friends.

Gather-pattern geometry in `Patterns.java` and the bag-color table in `BagReader.java` are ported from Natro Macro v1.1.2, so this project is licensed under GNU GPL v3 (see `NATRO_SOURCE_LICENSE.md`). If you share the APK, share the source too.

## Status
**Phases 1-6 complete.** Fast human farm, vision, presets, boosters/planters/smart quests, ship package, timer anti-detect jitter.

## Install (phone)
1. Build a debug APK: `gradle :app:assembleDebug` (or use the GitHub Actions workflow).
2. Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone.
3. Install it (allow install from this source).
4. Open **Natro Mobile** → enable the accessibility service in system settings.
5. Open Roblox Bee Swarm, run **Vision scan**, pick your field, press **Start farming**.

Sandbox (no phone): `bash tests/run.sh`

## How to use
1. Open the app and turn on **Natro Mobile** in Android accessibility settings (Setup, step 1).
2. A round **GO** bubble appears over everything. Drag it anywhere. Tap it to open the menu (Start, Open app, Hide).
3. Open Roblox, then tap the blue **Auto sense spots** button. It takes a screenshot, reads your exact screen size, and tries to lock joystick / bag / convert from the pixels.
4. Field defaults to **Pine Tree**. Walk-to-field and convert-at-hive are on by default.
5. Press **Start farming**. You get 3 seconds to switch to Roblox. It walks the route then gathers with small human-like jitter.
6. Stuck and self-correct fail-safes keep it aligned automatically. Use **Test walk to field** to check the path alone.
7. Press **STOP** on the bubble or the app to stop. The thumb is released right away.

### Setup items
- **Accessibility service:** required.
- **Auto sense spots:** recommended. Reads a live Roblox screenshot and fills joystick / bag / convert when the colors match.
- **Joystick / bag / convert:** still overridable by hand if the auto sense lands off.
- **Reset steps (optional):** the menu taps that reset your character. Add them in order.
- **Camera spot (optional):** only if you turn the camera before farming.

## Advanced
Walk speed, thumb distance, camera turns and swipe length, hive slot, wait after reset, flip directions, and a joystick test (switches to Roblox first).

## Fields and walking routes (new in v0.5.0)
- Pick your field under **How it runs**. The 17 fields match Natro's. Default is now **Pine Tree**.
- **Walk back to the field after converting** (on by default): after the bag empties, the app walks Natro's hive-to-field route and then resumes the pattern.
- **Auto walk to field on Start** (on by default): on Start the app walks the ramp then the field route before gathering.
- Routes come from Natro's `paths/gtf-*.ahk` files. `tools/gen_routes.py` turns them into `FieldRoutes.java`. The Cannon branch is skipped.
- Jumps and camera turns are left out, because a joystick can't jump and the route can't turn the camera. Pepper and Coconut use many jumps, so expect them to drift.
- Gathering now adds small duration jitter and stick micro-drift so the path looks less robotic.

## Timed item (new in v0.6.0)
- Record the taps for an item (for example the sprinkler in your hotbar) with **7. Timed item** in Setup. Add taps in order if the item needs more than one.
- Under **How it runs**, set **Use item every** to a number of minutes. The app uses the item right when farming starts, then again on that interval.
- When an item is due, the app lets go of the thumb between steps, taps the saved item steps, and resumes the pattern. It only does this while farming, not while walking or converting.
- Advanced has **Test item taps** (switch to Roblox during the 4 second wait) and a button to clear the saved taps.
- Placing an item may need you to aim or stand a certain way. Check where it lands on your first run.

## Reconnect (new in v0.7.0)
- **Private server link:** in Advanced, under **Reconnect**, paste the link to your private server and press **Save link**. The link is stored only on your phone.
- **Disconnect spot (Setup, step 8):** open Roblox's disconnect or rejoin screen, tap its button, then press Save here. The app records the color at that spot.
- **What happens:** while farming, the app reads that spot in each screenshot. Three readings in a row with a matching color mean Roblox dropped you. The app then opens your link, waits (set under Advanced, default 60 s), resets if you have reset steps, walks back to your field, and resumes farming.
- **Test rejoin now:** in Advanced, start farming first, then press this to check the link and walk-back without waiting for a disconnect.
- Use **Test rejoin now** to confirm the link works before you rely on it.

## Roblox closing (new in v0.8.0)
- If Roblox leaves the screen for 8 seconds (closed, crashed, or sent to the home screen), the app rejoins. Roblox coming back in that time cancels it.
- The app detects this from Android's window events. Roblox's package name is `com.roblox.client`; check it on your phone if the watch never fires.
- Any other app you switch to for more than 8 seconds also triggers a rejoin. Turn the watch off under Advanced if you need to use other apps while farming.

## Disconnect spot, links, and their limits (updated in v0.8.0)
- The disconnect spot records the average color of a 7x7 block, so one stray pixel or a small cursor doesn't break it.
- **Check disconnect spot** (under Advanced) shows the color on the screen right now next to the saved one, so you can see whether it matches instead of guessing.
- A game link is converted to a `roblox://` link. Android opens those in the Roblox app without asking which app to use.
- The first time, Android may still ask which app should open the link. Choose Roblox, and pick "Always" if it offers that.
- Roblox may show its own join prompt. The rejoin wait covers loading, but the app can't tap that prompt for you.
- If the spot stops matching after a Roblox update, re-record it with Change.

## What it does NOT do yet
- Three collect routes (Gummy beacon, RBPD elevator, Royal jelly dispenser) use Natro's cannon, so they are not in.
- Picture matching is used for the Make Honey button only. The cannon and other buttons still need their own pictures.

## Known limits
- Walking is time-based: tiles x 4 studs / walk speed. Haste, lag, and thumb distance change how far you really go, so tune "walk speed" and "thumb distance" on your device.
- Roblox's mobile thumbstick can be dynamic, appearing where you touch. If so, set the joystick spot to where the stick appears.
- Bag color can be off with night mode, blue-light filters, or HDR. Check that the "Bag" number matches the game.
- Screenshots need Android 11 or newer.
- Stop can take up to about 2 seconds to take effect.
- Macros can get a Roblox account moderated. Try an alt first.

## Build without a computer (GitHub Actions)
1. Create a GitHub repository and upload this ZIP's contents (keep the `.github` folder).
2. Open the Actions tab, run "Build APK", then download the `NatroMobile-debug-apk` artifact.
3. Unzip it and install `app-debug.apk`. Your phone will ask to allow installs from your browser or files app.

Or open the folder in Android Studio (SDK 35) and choose Build > Build APK(s).

## Changes in v1.8.0 (template matching: Make Honey picture)
- **Picture search** finds the Make Honey button from a saved picture. The search looks within 240 px of the saved spot first, then over the whole screen, so a button that moved a little is found quickly.
- **Check Make Honey picture** (Advanced, under Reconnect): switch to Roblox at the hive, and the app reports where the picture is and how close the match is (score 1.00 is identical; 0.85 or more counts as found). If it's gone, it says the closest match it saw.
- **Fallback:** when the picture is not on screen, the convert uses the last place the picture was found. That spot is updated each time the picture is found.
- **Plain buttons are refused.** A button with little contrast can't be found reliably, so the app asks you to pick one with more detail.
- **Precision:** the screen is sampled every 4 px, so a button is located to within 4 px. That's enough for a tap, but very small buttons may need a larger picture.
- The matcher was already in this copy when I looked. I checked it, fixed a test that expected the old fallback, and added the window search and the check button.

## Changes in v1.7.0 (Phase 5: 28 of 31 collect routes)
- **28 collect routes** are in now: every collect route except the three that use Natro's cannon. They are translated by `tools/gen_trips.py`.
- **Camera turns** (Natro's RotLeft / RotRight) are steps in the route. Each press is a camera swipe at your camera spot, the same length as Camera swipe length. Turns are undone on the way back.
- **Hive-slot switches** are resolved for the slot you pick, so each slot has its own route.
- **Bees in hive** (Advanced, under Trips): routes that check the bee count use the matching variant. Set this to your hive's bee count.
- **Jumps** are not done. The walking around each jump is kept, but the jump itself is skipped, so routes that jump may drift.
- **Interact (E) and shift presses** are skipped. Your destination taps take their place, so record a tap on the thing you collect from.
- Routes that turn the camera are skipped, with a message, until you set the camera spot.
- **Phone checks:** one camera press is one swipe, so tune Camera swipe length until a route's turns match the game. Check the route on your phone before you rely on it.

## Changes in v1.6.0 (Phase 5, first slice: trips from the hive)
- **Trips** (Advanced, under "Trips from the hive"): two trip slots. Each picks a route, an interval, and the spots to tap at the building.
- A trip runs after a convert, once the bag has emptied at the hive, if it is due. The app walks the route to the building, taps your spots in order, walks back the same way, and then goes to your field as usual.
- **Test trip** runs one trip now, so you can check the route and taps from Advanced. Switch to Roblox during the wait.
- Five of Natro's collect routes are in: Ant pass, Extreme mm, Honey dispenser, Stockings, and Wreath. They are translated by `tools/gen_trips.py`, and the translator skips any route it can't translate exactly, with the reason printed.
- Routes with jumps (Extreme mm has several) can drift, since the thumb can't jump.

## Changes in v1.5.0 (Phase 4: extra patterns and walk-speed check)
- Ported Natro's four remaining gather patterns: **Auryn**, **CornerXSnake**, **SuperCat**, and **e_lol**. They appear in the Pattern list. They're translated from Natro's own `patterns/*.ahk` files by `tools/gen_patterns.py`, so they track Natro closely.
- Keys are held the way Natro holds them, so diagonal and held-key moves match.
- **Walk speed check** (Advanced, under Movement): walks a known 10 tiles. Measure how far the character really went, type the tiles into the box, and press **Set walk speed from that distance**. The speed is scaled to match, within the slider range (10–60).
- Simulator tests check each pattern's totals against an independent evaluation of Natro's files (48 cases: each pattern at three sizes, reps 1 and 3, both facing settings).

## Changes in v1.4.0 (Phase 6 ship + anti-detect)
- VersionName 1.4.0 / versionCode 14.
- Install section and phase status locked for ship.
- Anti-detect: non-fixed start delay; item/booster/planter/quest intervals jitter ±12%; stuck/self-correct/hive timers jitter.
- Does **not** modify Roblox, hide the app, or guarantee against bans. It only avoids perfectly robotic timers.

## Changes in v1.3.2 (fast human farm)
- Human mode ON by default again, but tuned for speed (tiny drift, rare short pauses).
- Default walk speed 48 (slider up to 60).
- Tap gaps stay short even with human mode (~160-300 ms).
- Tests still lock exact 60 ms slides.

## Changes in v1.3.1 (fast farm)
- Human mode defaults OFF for max speed.
- Default walk speed 42 (slider up to 60).
- Faster stick slides and much shorter gaps between taps when human mode is off.
- Human mode still available if you want slower/random motion.

## Changes in v1.3.0 (Phase 5 human polish)
- Human mode (on by default): duration jitter, stick drift, random micro-pauses while farming.
- Human level: Light / Normal / Heavy controls how strong the randomness is.
- Taps get small pixel offsets and variable gaps between them.
- Tests still force exact moves via disableJitterForTests.

## Changes in v1.2.4 (full green Complete only)
- Partial green progress fill on red rows no longer counts as done.
- Requires a wide solid green horizontal run across the left quest panel (true Complete row).
- Flow unchanged: full green Complete → turn-in taps → NPC next quest.

## Changes in v1.2.3 (real BSS quest colors)
- Quest board tuned from real screenshots: green Complete rows vs red/coral in-progress rows.
- Scans left-side quest list only. Green Complete → turn-in + NPC path. Red progress → skip.
- Copy updated for Spirit Bear / Talk to NPC flow.

## Changes in v1.2.2 (green turn-in + NPC next quest)
- Green = finished Turn In (click). Grey = incomplete pollen/progress (ignore).
- Smart quest only fires on strong green blobs, never grey.
- After green turn-in: optional saved turn-in taps, then NPC sequence to get the next quest.
- Setup: step 10 turn-in extras, step 11 walk/talk to quest character.

## Changes in v1.2.1 (smart quest vision)
- Quest claim-button vision: scans for green/yellow claim blobs before firing quest taps.
- Smart quest mode (on by default): only runs quest taps when claim UI is detected; soft 25s retry if not.
- Falls back to saved quest taps if screenshot fails or panel is open without a clear blob.
- Toggle under How it runs: Smart quest (only tap when claim UI seen).

## Changes in v1.2.0 (Phase 4 boosters planters quests)
- Booster, planter, and quest tap sequences with their own intervals.
- Priority between gather steps: quest > booster > planter > item.
- Setup rows 8-10 to record taps; Advanced clear buttons for each.
- Fires once at farm start then on interval while gathering.

## Changes in v1.1.0 (Phase 3 field intelligence)
- FieldPresets: every field gets a recommended pattern, size, camera turns, and facing-corner flag.
- Picking a field applies the preset automatically (still overridable).
- Status line shows field + preset + hive slot.
- **I'm lost** button: force reset + walk to field (works while farming or idle).
- Sandbox checks all 17 presets.

## Changes in v1.0.0 (Phase 2 complete)
- Phase 2 locked: vision routing, live convert, hive-pad, field markers, wrong-scene fail-safe.
- runFarm clears hive-scene timer so convert does not false-trigger wrong-scene.
- Extra sandbox checks for hive-pad and sceneOnly null safety.
- UI and README mark Phase 2 complete.

## Changes in v0.9.7 (Phase 2 vision - scene routing)
- beginRun vision check: if already ON_FIELD, skip walk and start gathering immediately.
- Field markers: saturated token/flower blobs help classify ON_FIELD.
- Hive-pad find: scans bottom-center for brown/wood/gray pad colors instead of pure ratio.
- Keeps prior convert/auto-sense vision behavior from 0.9.6.

## Changes in v0.9.6 (Phase 2 vision - convert + hive pad)
- Live vision pass right before Make Honey: re-scans convert button at the hive and taps the fresh spot.
- Auto sense refreshes spots when vision disagrees with saved coords by a meaningful margin.
- Hive-pad estimate when scene is AT_HIVE (bottom-center ratio).
- UI: Vision scan button + Phase 2 status copy.
- Bag line and status report hive/field scene from bag-reading frames.

## Changes in v0.9.5 (Phase 2 vision - first pass)
- AutoSense rewritten: continuous pollen-bar run detection, contrast-based joystick, warm-blob convert button.
- Scene classifier: AT_HIVE vs ON_FIELD vs UNKNOWN from bag + convert + green terrain samples.
- Bag line shows | hive or | field when the scene is known.
- Wrong-scene fail-safe: if the screen looks like the hive for ~90s while farming, auto realign to field.
- Sandbox tests cover the new bag-strip and scene heuristics.

## Changes in v0.9.0 (Phase 1 complete)
- Reset taps are now fully optional. Empty list still walks the ramp after a short wait.
- Convert and fail-safe recovery both handle missing reset taps cleanly.
- New **Test walk to field** button under How it runs (no farming, just the path).
- Clearer status messages during resets, walks, and fail-safes.
- Version and status marked Phase 1 complete.

## Changes in v0.8.3 (fail-safes)
- Stuck detector: if bag % stays flat for N minutes while farming, auto reset + walk back to field.
- Periodic self-correct: every N minutes force a clean reset and re-walk so small drifts never stack.
- Both timers adjustable under How it runs (default stuck 4 min, self-correct 12 min). Set either to 0 to turn off.
- Recovery uses the same reset taps + ramp + field route path as convert.

## Changes in v0.8.2 (live screen sense)
- New AutoSense engine: takes a real screenshot, scans pixels for pollen-bar colors, joystick zone, and convert button zone.
- Big blue **Auto sense spots** button on the home screen. Open Roblox first, then tap it.
- On Start it also kicks a background auto-sense if any spots are still empty.
- Still falls back to screen-ratio defaults when the screenshot scan is not confident.
- Screen width + height are read live from DisplayMetrics every time.

## Changes in v0.8.1 (auto / human pass)
- Smart defaults: joystick, bag, and convert spots auto-fill from screen ratios if still zero.
- Default field is now Pine Tree. Walk-to-field and Convert-at-hive are on by default.
- Start forces walkFirst when a real field is selected so it goes there by itself.
- Human-like gathering: ±8% duration jitter + small stick micro-drift so paths look less perfect.
- UI text updated for the lower-setup flow.

## Changes in v0.8.0
- Roblox closing or leaving the screen for 8 seconds triggers a rejoin (window events), with a switch to turn it off.
- Disconnect spot uses a 7x7 average, and Check disconnect spot shows the current versus saved colors.
- Game links open as roblox:// links, so Android skips the browser chooser.
- Simulation tests: 124 checks, including saving the spot and the Roblox-closed watch.

## Changes in v0.7.0
- Reconnect: disconnect-spot detection, private server link, rejoin wait, walk back to the field, and a test button.
- Simulation tests now cover reconnect (124 checks).

## Testing without a phone (new in v0.6.1)
`bash tests/run.sh` runs the engine on a fake clock and checks the gestures it sends (124 checks). It needs only a JDK. CI runs it before every APK build. See `tests/README.md` for what is and isn't covered. The tests do not replace trying the app on a phone.

## Changes in v0.6.1
- A timed item is now used right when farming starts, even if the phone has been on for less than its interval.
- The bag cooldown no longer blocks the first full-bag trigger on a freshly booted phone.
- Added the simulation tests and run them in CI.

## Changes in v0.6.0
- Timed item: saved taps, used on an interval while farming, with a test.

## Changes in v0.5.0
- Field picker, walk back to the field after converting, and optional walk to the field on Start.
- `FieldRoutes.java` generated from Natro's gather-to-field paths.

## Changes in v0.4.0
- New friendly interface: a Start button, a setup checklist, a pattern picker, sliders, and an Advanced screen.
- Floating GO/STOP bubble replaces the button bar. It is draggable and has a menu.
- Tap-to-save overlay with a ring that shows where you tapped and a Save/Cancel step.
- Reset-step taps are no longer performed while recording. That could have clicked something by accident in the game.
- Fixed the hive walk after a reset: it was 4x too short because of a unit mistake (Natro's walk takes tiles, not studs).


## v1.8.0 source expansion and sandbox

This package includes a deterministic JVM sandbox and an explicit task-priority arbiter.
Run `bash tests/run.sh` to execute the JVM and sandbox suite. The sandbox uses simulated
time and injected screenshot/gesture failures; it is not an Android emulator.

See `PROJECT_AUDIT.md`, `ARCHITECTURE.md`, `SANDBOX_GUIDE.md`,
`DEVICE_TEST_MATRIX.md`, and `PRODUCTION_READINESS.md` before attempting release.

The source-level suite passed 750 checks in the packaging environment. Android lint,
APK compilation, signing, and physical-device validation have **not** been run here.
